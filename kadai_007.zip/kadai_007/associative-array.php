<?php

$personal_data = ['name' => 'onion', 'price' => 200, 'weight' => '160'];
print_r($personal_data)


?>

